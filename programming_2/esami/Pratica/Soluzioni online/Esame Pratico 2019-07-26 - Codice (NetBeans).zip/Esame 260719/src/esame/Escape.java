/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esame;

import static esame.Ball.BASE_RADIUS;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import static javafx.scene.input.KeyCode.DOWN;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author picco
 */
public class Escape extends Application {
  static final double FIELD_DIM = 500; 
  static final double STEP = 10;
  static final int STEP_POINTS = 100;
  static final int SPAWN_ITERATIONS = 10;
    
  Text pointsText = new Text();
  Text gameOverText = new Text();
  Group field = new Group();
  
  List<Ball> balls = new ArrayList<>();
  int points = 0;
  int iterations = SPAWN_ITERATIONS;
  boolean gameover = false;
  User u = new User();
        
  private void placeAtRandom(Ball b) {
    Random rand = new Random();
    boolean ok = false;
    while(!ok) {
      b.setPosition((FIELD_DIM-BASE_RADIUS)*rand.nextDouble(), (FIELD_DIM-BASE_RADIUS)*rand.nextDouble());
      if (!b.checkCollision(u)) ok = true;
    }
    System.out.println(b);
  }
      
  private void addBall(Ball b) {
    balls.add(b);
    placeAtRandom(b);
    field.getChildren().add(b.getCircle());
    b.redraw();
    System.out.println(b);
  }
  
  @Override
  public void start(Stage primaryStage) {         
    addBall(u);
    addBall(new Striker());
    addBall(new Wanderer());
    addBall(new Bubbler());
    
    Scene scene = new Scene(field, FIELD_DIM, FIELD_DIM);
        
    scene.setOnKeyPressed(new EventHandler<KeyEvent>() {
      @Override
      public void handle(KeyEvent event) {
        if (!gameover) {
          KeyCode key = event.getCode();
          double x = u.x;
          double y = u.y;
          switch (key) {
            case UP:
              y = y - STEP;
              break;
            case DOWN:
              y = y + STEP;
              break;
            case LEFT:
              x = x - STEP;
              break;
            case RIGHT:
              x = x + STEP;
              break;
          }
          points = points + STEP_POINTS;
          u.setPosition(x, y);
          u.redraw();
          for (Ball b : balls) {
            if(b instanceof Enemy) {
              Enemy e = (Enemy) b;
              e.nextPosition();
              if (e.checkCollision(u)) {
                e.setColor(Color.RED);
                u.setColor(Color.RED);
                u.redraw();
                gameOverText.setText("GAME OVER");
                gameover = true;             
              }
            }
            b.redraw();
          }
          pointsText.setText("Points: " + points);
          if (iterations > 0) 
            iterations --;
          else {
            iterations = SPAWN_ITERATIONS;
            switch(new Random().nextInt(3)) {
              case 0: addBall(new Striker()); break; 
              case 1: addBall(new Wanderer()); break; 
              case 2: addBall(new Bubbler()); break; 
            }
          }
        }
      }
    });
        
    primaryStage.setTitle("Escape!");
    primaryStage.setScene(scene);
    primaryStage.show();
    
    VBox root2 = new VBox();
    root2.setAlignment(Pos.CENTER);
    root2.getChildren().addAll(pointsText,gameOverText);
            
    pointsText.setFont(Font.font("Verdana", 20));     
    gameOverText.setFont(Font.font("Verdana", 20));   
    
    Scene scene2 = new Scene(root2, 200, 100);
    Stage stage2 = new Stage();
    stage2.setScene(scene2);
    stage2.setX(100);
    stage2.setX(200);
    stage2.show(); 
  }

  
  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    launch(args);
  }
  
}
