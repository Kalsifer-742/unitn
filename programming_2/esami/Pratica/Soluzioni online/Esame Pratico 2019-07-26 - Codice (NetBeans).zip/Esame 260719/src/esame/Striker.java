/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esame;

import java.util.Random;
import javafx.scene.paint.Color;

/**
 *
 * @author picco
 */
public class Striker extends Enemy {
  int dir;
            
  public Striker() {
    setColor(Color.BLUE);
    setRadius(BASE_RADIUS);
    dir = new Random().nextInt(8);
  }

  @Override
  public void nextPosition() {  
    setDirection(dir);
  }
}
