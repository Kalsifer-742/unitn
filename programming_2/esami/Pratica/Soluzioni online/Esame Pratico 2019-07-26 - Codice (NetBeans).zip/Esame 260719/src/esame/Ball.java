/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esame;

import static esame.Escape.FIELD_DIM;
import static esame.Escape.STEP;
import static java.lang.Math.pow;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

/**
 *
 * @author picco
 */
public abstract class Ball {
  protected static final double BASE_RADIUS = 20;
  double x,y;
  double radius; 
  Color color;
  Circle c = new Circle(); 
              
  public final void setRadius(double radius) {
    this.radius = radius;
  }
  
  public final void setColor(Color color) {
    this.color = color;
  }
  
  public final Circle getCircle() {
    return c;
  }
   
  public final boolean checkCollision(Ball b) {
    if (b == this) return false;
    //compute distance
    double d = Math.sqrt(pow(this.x-b.x,2)+pow(this.y-b.y,2)); 
    double sumRadii = this.radius + b.radius;
    System.out.println(b + " " + this + " " + "distance: " + d + " sumradii: " + sumRadii);
    return sumRadii >= d;  
  }  
  
  public final void setPosition(double x, double y) {
    if (x < 0) x = FIELD_DIM - STEP;
    if (y < 0) y = FIELD_DIM - STEP;
    if (x > FIELD_DIM) x = x % FIELD_DIM;
    if (y > FIELD_DIM) y = y % FIELD_DIM;
    this.x = x;
    this.y = y;
  }
  
  public final void redraw() {
    c.setCenterX(x);
    c.setCenterY(y);
    c.setFill(color);
    c.setRadius(radius);
  }  

  @Override
  public String toString() {
    return this.getClass().getSimpleName() + "["+ x + ", " + y + ", r= " + radius + "]";
  } 
}
