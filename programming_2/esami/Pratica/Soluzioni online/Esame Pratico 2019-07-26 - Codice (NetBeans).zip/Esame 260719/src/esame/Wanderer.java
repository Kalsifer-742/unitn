/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esame;

import java.util.Random;
import javafx.scene.paint.Color;

/**
 *
 * @author picco
 */
public class Wanderer extends Enemy {
  static final int ITERATIONS = 5; 
  int dir;
  int count;
  
  public Wanderer() {
    setColor(Color.DARKBLUE);
    setRadius(BASE_RADIUS);
    resetDirection();
  }
  
  private void resetDirection() {
    count = ITERATIONS;
    dir = pickRandomDirection();
  }
  
  @Override
  public void nextPosition() {
    if(count>0)       
      count--;
    else 
      resetDirection();
    setDirection(dir);
  }
}
