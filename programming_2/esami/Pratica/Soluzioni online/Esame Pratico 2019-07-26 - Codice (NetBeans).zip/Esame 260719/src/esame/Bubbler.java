/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esame;

import java.util.Random;
import javafx.scene.paint.Color;

/**
 *
 * @author picco
 */
public class Bubbler extends Wanderer {
  static final int PROB = 10;
  
  public Bubbler() {
    super();
    color = Color.LIGHTBLUE;
  }

  @Override
  public void nextPosition() {
    int probability = new Random().nextInt(PROB);
    if (probability == 0) {
      radius = radius * 1.2;
    }
    super.nextPosition(); 
  }
  
  
  
}
