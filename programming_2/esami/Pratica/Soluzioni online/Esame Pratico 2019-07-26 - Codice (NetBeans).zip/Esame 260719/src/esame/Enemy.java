/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esame;

import static esame.Escape.STEP;
import java.util.Random;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

/**
 *
 * @author picco
 */
public abstract class Enemy extends Ball {
  public void setDirection(int dir) {
    switch (dir) {
      case 0: setPosition(x + STEP, y); break;
      case 1: setPosition(x - STEP, y); break;
      case 2: setPosition(x + STEP, y + STEP); break;
      case 3: setPosition(x - STEP, y + STEP); break;
      case 4: setPosition(x, y + STEP); break;
      case 5: setPosition(x, y - STEP); break;
      case 6: setPosition(x + STEP, y - STEP); break;
      case 7: setPosition(x - STEP, y - STEP); break;
    }
  }
  
  public int pickRandomDirection() {
    return new Random().nextInt(8);
  }
  
  public abstract void nextPosition();
}
