/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esame;

/**
 *
 * @author picco
 */
public class Studente extends Persona {
  static final String LT = "LT";
  static final String LM = "LM";
  String universita;
  String tipolaurea;

  public Studente(String nome, String cf, int natoil, String universita, String tipolaurea) {
    super(nome, cf, natoil);
    this.universita = universita;
    this.tipolaurea = tipolaurea;
  }

  public String getUniversita() {
    return universita;
  }

  public String getTipoLaurea() {
    return tipolaurea;
  }
  
  @Override
  public double getTariffa() {
    double sconto = 0;
    if (tipolaurea.compareTo(LT)==0) {
      sconto = 0.4;
    } else if (tipolaurea.compareTo(LM)==0) {
      sconto = 0.2;
    } else {
      System.out.println("S - Errore fatale!");
      System.exit(1);
    }
    return Math.min(Persona.TARIFFA_BASE * (1 - sconto), super.getTariffa());
  }

  @Override
  public String toString() {
    return super.toString() + universita + " " + tipolaurea + " ";
  }
  
}
