/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esame;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import java.util.*;
import javafx.geometry.Insets;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

/**
 *
 * @author picco
 */
public class Palestra extends Application {
  static final int TUTTI = 0;
  static final int STUDENTI = 1;
  static final int ATLETI = 2;
  
  static final int PER_NOME = 0;
  static final int PER_ETA = 1;
  
  int filterMode = TUTTI;
  int sortMode = PER_NOME;
  
  int current = 0;
  List<Persona> abbonati = new ArrayList<>();
  
  Button tutti = new Button("Tutti");
  Button studenti = new Button("Studenti");
  Button atleti = new Button("Atleti");
  Button nome = new Button("per nome");
  Button eta = new Button("per eta");
  
  public void grayButtons() {
    switch (filterMode) {
      case TUTTI:
        tutti.setDisable(true);
        studenti.setDisable(false);
        atleti.setDisable(false);
        break;
      case STUDENTI:
        tutti.setDisable(false);
        studenti.setDisable(true);
        atleti.setDisable(false);
        break;
      case ATLETI:
        tutti.setDisable(false);
        studenti.setDisable(false);
        atleti.setDisable(true);
        break;
    }
    switch (sortMode) {
      case PER_NOME:
        nome.setDisable(true);
        eta.setDisable(false);
        break;
      case PER_ETA:
        nome.setDisable(false);
        eta.setDisable(true);
        break;
    }
  }
  
  public List<Persona> filter(List<Persona> l) {
    List<Persona> res = new ArrayList<>();
    for (Persona p : l) {
      switch(filterMode) {
        case TUTTI:
          res.add(p); break;
        case STUDENTI:
          if (p instanceof Studente) res.add(p); break;
        case ATLETI:
          if (p instanceof IAtleta) res.add(p); break;
      }
    }
    return res;
  }
  
  public String format(List<Persona> l) {
    String res = "\n";
    for(Persona p : l)
      res += p.toString() + "| tariffa: " + p.getTariffa() + "\n";
    return res;
  }
  
  
  @Override
  public void start(Stage primaryStage) {    
    Text text = new Text(format(abbonati));
    
    Insets inset = new Insets(0,0,10,0);
    
    HBox bottoniPersona = new HBox();
    bottoniPersona.setSpacing(10);
    bottoniPersona.setPadding(inset);
    bottoniPersona.getChildren().addAll(tutti, studenti, atleti);
                    
    tutti.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        filterMode = TUTTI;
        grayButtons();
        text.setText(format(filter(abbonati)));
      }
    });
    
    studenti.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        filterMode = STUDENTI;
        grayButtons();
        text.setText(format(filter(abbonati)));
      }
    });
    
    atleti.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        filterMode = ATLETI;
        grayButtons();
        text.setText(format(filter(abbonati)));
      }
    });
    
    HBox bottoniOrdina = new HBox();
    bottoniOrdina.setSpacing(10);
    bottoniPersona.setPadding(inset);
    bottoniOrdina.getChildren().addAll(nome, eta);
    
    nome.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        sortMode = PER_NOME;
        Collections.sort(abbonati);
        grayButtons();
        text.setText(format(filter(abbonati)));
      }
    }); 
    
    eta.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        sortMode = PER_ETA;
        Collections.sort(abbonati, new CompareByAge());
        grayButtons();
        text.setText(format(filter(abbonati)));
      }
    });
        
    Button exit = new Button("Exit");
    exit.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent event) {
        System.out.println("Exiting...");
        System.exit(0);
      }
    });
      
    grayButtons();
            
    AnchorPane top = new AnchorPane();
    top.getChildren().addAll(bottoniOrdina,bottoniPersona);
    top.setTopAnchor(bottoniPersona, 10.0);
    top.setLeftAnchor(bottoniPersona, 10.0);
    top.setTopAnchor(bottoniOrdina, 10.0);
    top.setRightAnchor(bottoniOrdina, 10.0);
    top.setBackground(new Background(new BackgroundFill(Color.CADETBLUE, CornerRadii.EMPTY, Insets.EMPTY)));
        
    AnchorPane bottom = new AnchorPane();
    bottom.getChildren().add(exit);
    bottom.setBottomAnchor(exit,10.0);
    bottom.setRightAnchor(exit, 10.0); 
    bottom.setPadding(new Insets(10,0,0,0));
    
    BorderPane root = new BorderPane();
    root.setTop(top);
    root.setCenter(text);
    root.setBottom(bottom);
    
    Scene scene = new Scene(root, 500, 250);
    
    primaryStage.setTitle("Palestra");
    primaryStage.setScene(scene);
    primaryStage.show();
  }

  public Palestra() {
    abbonati.add(new Persona("Rossi Mario","1",1950));
    abbonati.add(new Persona("Rossi Carla","2",1990));
    abbonati.add(new Studente("Bianchi Giovanni","3",1995,"UNITN",Studente.LT));
    abbonati.add(new Studente("Bianchi Anna","4",1990,"UNIPD",Studente.LM));
    abbonati.add(new Atleta("Verdi Giacomo","5",1991,"nuoto",IAtleta.NAZ));
    abbonati.add(new Atleta("Verdi Alice","6",1967,"curling",IAtleta.INTER));
    abbonati.add(new StudenteAtleta("Ferrari Alberto","7",1993,"UNITN",Studente.LM,"atletica",IAtleta.INTER));
    abbonati.add(new StudenteAtleta("Ferrari Vincenzo","8",1997,"UNIVR",Studente.LT,"atletica",IAtleta.NAZ));
  }
  
  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    launch(args);
  }
  
}
