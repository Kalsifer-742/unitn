/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esame;

/**
 *
 * @author picco
 */
public class Persona implements Comparable<Persona> {
  static final double TARIFFA_BASE = 1000;
  static final double SCONTO_SENIOR = 0.35;
  String nome;
  String cf;
  int natoil;

  public Persona(String nome, String cf, int natoil) {
    this.nome = nome;
    this.cf = cf;
    this.natoil = natoil;
  }
  
  public double getTariffa() { 
    if (natoil <= 1968) 
      return TARIFFA_BASE * (1-SCONTO_SENIOR);
    else return TARIFFA_BASE; 
  }

  @Override
  public String toString() {
    return nome + " " + cf + " " + natoil + " ";
  }    
  
  public int compareTo(Persona p) {
    return nome.compareTo(p.nome);
  }
}


