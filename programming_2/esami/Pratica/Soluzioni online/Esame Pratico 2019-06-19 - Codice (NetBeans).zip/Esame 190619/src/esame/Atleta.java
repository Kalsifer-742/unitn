/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esame;

/**
 *
 * @author picco
 */
public class Atleta extends Persona implements IAtleta {
  String disciplina;
  String rilevanza; 

  public Atleta(String nome, String cf, int natoil, String disciplina, String rilevanza) {
    super(nome, cf, natoil);
    this.disciplina = disciplina;
    this.rilevanza = rilevanza;
  }

  public String getDisciplina() {
    return disciplina;
  }

  public String getRilevanza() {
    return rilevanza;
  }

  @Override
  public double getTariffa() {
    double sconto = 0;
    
    if(rilevanza.compareTo(NAZ) == 0)
      sconto = 0.3;  
    else if(rilevanza.compareTo(INTER)==0)
      sconto = 0.5; 
    else {
      System.out.println("S - Errore fatale!"); 
      System.exit(1);
    } 
    return Math.min(Persona.TARIFFA_BASE*(1-sconto),super.getTariffa());
  }

  @Override
  public String toString() {
    return super.toString() + disciplina + " " + rilevanza + " ";
  } 
}
