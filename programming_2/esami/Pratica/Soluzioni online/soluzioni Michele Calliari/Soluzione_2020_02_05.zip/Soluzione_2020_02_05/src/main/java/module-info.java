module com.soluzione_2020_02_05 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.soluzione_2020_02_05 to javafx.fxml;
    exports com.soluzione_2020_02_05;
}