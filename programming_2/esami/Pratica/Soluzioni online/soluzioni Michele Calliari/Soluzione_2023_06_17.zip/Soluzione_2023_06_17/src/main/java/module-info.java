module org.example.soluzione_2023_06_17 {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.soluzione_2023_06_17 to javafx.fxml;
    exports org.example.soluzione_2023_06_17;
}