module org.example.soluzione_2018_06_15 {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.soluzione_2018_06_15 to javafx.fxml;
    exports org.example.soluzione_2018_06_15;
}