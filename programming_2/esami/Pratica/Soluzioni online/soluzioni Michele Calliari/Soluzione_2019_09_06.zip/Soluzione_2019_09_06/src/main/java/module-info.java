module com.soluzione_2019_09_06 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.soluzione_2019_09_06 to javafx.fxml;
    exports com.soluzione_2019_09_06;
}