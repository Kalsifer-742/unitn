module com.soluzione_2020_01_19 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.soluzione_2020_01_19 to javafx.fxml;
    exports com.soluzione_2020_01_19;
}