module com.soluzione_2024_02_16 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.soluzione_2024_02_16 to javafx.fxml;
    exports com.soluzione_2024_02_16;
}