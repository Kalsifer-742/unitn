package model.enums;

public enum TipologiaFan {
    Parete,Piantana,Soffitto
}
