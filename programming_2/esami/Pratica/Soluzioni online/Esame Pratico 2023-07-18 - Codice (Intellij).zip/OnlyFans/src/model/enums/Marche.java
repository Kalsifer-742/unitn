package model.enums;

public enum Marche {
    Ariete, Bosch, Parkside
}
