package model.enums;

public enum Alimentazionie {
    Meccanica,Batteria,Presa
}
