package model.alimentazioni;

import model.enums.Alimentazionie;

public class AlimentazioneMeccanica extends AbstractAlimentazione{

    public AlimentazioneMeccanica(){
        this.fun = (arg)->{return arg * 1;};
        this.al= Alimentazionie.Meccanica;
    }
}
