package model.fans;

public interface FanInterface {

    int getCosto();
}
