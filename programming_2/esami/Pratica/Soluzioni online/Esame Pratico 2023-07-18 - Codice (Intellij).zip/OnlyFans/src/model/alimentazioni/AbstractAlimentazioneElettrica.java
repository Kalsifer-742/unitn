package model.alimentazioni;

public abstract class AbstractAlimentazioneElettrica extends AbstractAlimentazione{
}
