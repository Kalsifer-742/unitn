package model.geralt;

public enum Mutation {
    Empty,
    Str,
    Vel,
    Tol,
    Igni,
    Quen,
}