package model.exceptions;

public class SpellException extends Exception{
}
