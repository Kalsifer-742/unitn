package model.exceptions;

public class AggiuntaException extends Exception{
}
