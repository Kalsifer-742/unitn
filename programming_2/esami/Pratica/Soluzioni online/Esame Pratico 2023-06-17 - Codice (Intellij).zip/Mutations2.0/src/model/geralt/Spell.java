package model.geralt;

public enum Spell {
    Igni,
    Quen,
}