package model.functions;

import java.util.function.Consumer;

public interface MyConsumer<T> extends Consumer<T> {}
